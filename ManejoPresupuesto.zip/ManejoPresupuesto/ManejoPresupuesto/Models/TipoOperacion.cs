﻿namespace ManejoPresupuesto.Models
{
    public enum TipoOperacion
    {
        Ingreso = 1,
        Gastos = 2
    }
}
