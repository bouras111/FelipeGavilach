﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Principal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Principal))
        Me.ToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me.ToolStripSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator3 = New System.Windows.Forms.ToolStripSeparator()
        Me.ToolStripSeparator4 = New System.Windows.Forms.ToolStripSeparator()
        Me.TSBPersona = New System.Windows.Forms.ToolStripButton()
        Me.TSBPaciente = New System.Windows.Forms.ToolStripButton()
        Me.TSBCita = New System.Windows.Forms.ToolStripButton()
        Me.TSBInventario = New System.Windows.Forms.ToolStripButton()
        Me.TSBUsuario = New System.Windows.Forms.ToolStripButton()
        Me.TSBSalida = New System.Windows.Forms.ToolStripButton()
        Me.ToolStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ToolStrip1
        '
        Me.ToolStrip1.ImageScalingSize = New System.Drawing.Size(24, 24)
        Me.ToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TSBPersona, Me.TSBPaciente, Me.ToolStripSeparator1, Me.TSBCita, Me.ToolStripSeparator2, Me.TSBInventario, Me.ToolStripSeparator3, Me.TSBUsuario, Me.ToolStripSeparator4, Me.TSBSalida})
        Me.ToolStrip1.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow
        Me.ToolStrip1.Location = New System.Drawing.Point(0, 0)
        Me.ToolStrip1.Name = "ToolStrip1"
        Me.ToolStrip1.Size = New System.Drawing.Size(176, 578)
        Me.ToolStrip1.Stretch = True
        Me.ToolStrip1.TabIndex = 1
        Me.ToolStrip1.Text = "ToolStrip1"
        '
        'ToolStripSeparator1
        '
        Me.ToolStripSeparator1.Name = "ToolStripSeparator1"
        Me.ToolStripSeparator1.Size = New System.Drawing.Size(173, 6)
        '
        'ToolStripSeparator2
        '
        Me.ToolStripSeparator2.Name = "ToolStripSeparator2"
        Me.ToolStripSeparator2.Size = New System.Drawing.Size(173, 6)
        '
        'ToolStripSeparator3
        '
        Me.ToolStripSeparator3.Name = "ToolStripSeparator3"
        Me.ToolStripSeparator3.Size = New System.Drawing.Size(173, 6)
        '
        'ToolStripSeparator4
        '
        Me.ToolStripSeparator4.Name = "ToolStripSeparator4"
        Me.ToolStripSeparator4.Size = New System.Drawing.Size(173, 6)
        '
        'TSBPersona
        '
        Me.TSBPersona.AutoSize = False
        Me.TSBPersona.BackgroundImage = Global.MedicinaIntegrativa.My.Resources.Resources.Persona
        Me.TSBPersona.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBPersona.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBPersona.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPersona.Name = "TSBPersona"
        Me.TSBPersona.Size = New System.Drawing.Size(80, 80)
        Me.TSBPersona.TextAlign = System.Drawing.ContentAlignment.BottomCenter
        Me.TSBPersona.ToolTipText = "Persona"
        '
        'TSBPaciente
        '
        Me.TSBPaciente.AutoSize = False
        Me.TSBPaciente.BackgroundImage = Global.MedicinaIntegrativa.My.Resources.Resources.Paciente1
        Me.TSBPaciente.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBPaciente.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBPaciente.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBPaciente.Name = "TSBPaciente"
        Me.TSBPaciente.Size = New System.Drawing.Size(80, 80)
        Me.TSBPaciente.Text = "ToolStripButton1"
        '
        'TSBCita
        '
        Me.TSBCita.AutoSize = False
        Me.TSBCita.BackgroundImage = CType(resources.GetObject("TSBCita.BackgroundImage"), System.Drawing.Image)
        Me.TSBCita.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBCita.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBCita.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBCita.Name = "TSBCita"
        Me.TSBCita.Size = New System.Drawing.Size(80, 80)
        Me.TSBCita.Text = "ToolStripButton1"
        '
        'TSBInventario
        '
        Me.TSBInventario.AutoSize = False
        Me.TSBInventario.BackgroundImage = CType(resources.GetObject("TSBInventario.BackgroundImage"), System.Drawing.Image)
        Me.TSBInventario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBInventario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBInventario.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBInventario.Name = "TSBInventario"
        Me.TSBInventario.Size = New System.Drawing.Size(80, 80)
        Me.TSBInventario.Text = "ToolStripButton1"
        '
        'TSBUsuario
        '
        Me.TSBUsuario.AutoSize = False
        Me.TSBUsuario.BackgroundImage = CType(resources.GetObject("TSBUsuario.BackgroundImage"), System.Drawing.Image)
        Me.TSBUsuario.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBUsuario.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBUsuario.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBUsuario.Name = "TSBUsuario"
        Me.TSBUsuario.Size = New System.Drawing.Size(80, 80)
        Me.TSBUsuario.Text = "ToolStripButton1"
        '
        'TSBSalida
        '
        Me.TSBSalida.AutoSize = False
        Me.TSBSalida.BackgroundImage = CType(resources.GetObject("TSBSalida.BackgroundImage"), System.Drawing.Image)
        Me.TSBSalida.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.TSBSalida.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TSBSalida.ImageTransparentColor = System.Drawing.Color.Magenta
        Me.TSBSalida.Name = "TSBSalida"
        Me.TSBSalida.Size = New System.Drawing.Size(80, 80)
        Me.TSBSalida.Text = "ToolStripButton1"
        '
        'Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(176, 552)
        Me.Controls.Add(Me.ToolStrip1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Medicina Integrativa"
        Me.ToolStrip1.ResumeLayout(False)
        Me.ToolStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents ToolStrip1 As ToolStrip
    Friend WithEvents TSBPersona As ToolStripButton
    Friend WithEvents TSBPaciente As ToolStripButton
    Friend WithEvents ToolStripSeparator1 As ToolStripSeparator
    Friend WithEvents TSBCita As ToolStripButton
    Friend WithEvents ToolStripSeparator2 As ToolStripSeparator
    Friend WithEvents TSBUsuario As ToolStripButton
    Friend WithEvents ToolStripSeparator3 As ToolStripSeparator
    Friend WithEvents TSBSalida As ToolStripButton
    Friend WithEvents TSBInventario As ToolStripButton
    Friend WithEvents ToolStripSeparator4 As ToolStripSeparator
End Class
