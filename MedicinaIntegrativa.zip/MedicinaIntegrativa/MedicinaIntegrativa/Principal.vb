﻿Public Class Principal
    Private Sub TSBSalida_Click(sender As Object, e As EventArgs) Handles TSBSalida.Click
        End
    End Sub

    Private Sub Principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Me.Width = 170
        Me.Height = 552
    End Sub

    Private Sub TSBUsuario_Click(sender As Object, e As EventArgs) Handles TSBUsuario.Click
        frmUsuario.Show()
    End Sub

End Class