﻿namespace ManejoPresupuesto.Models
{
    public class IndiceCuentasViewModel
    {

        public String TipoCuenta { get; set; }
        public IEnumerable<Cuenta> Cuentas { get; set; }
        public decimal balance => Cuentas.Sum(x=> x.Balance);


    }
}
