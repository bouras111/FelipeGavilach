﻿using Dapper;
using ManejoPresupuesto.Models;
using Microsoft.Data.SqlClient;

namespace ManejoPresupuesto.Servicios
{
    public interface IRepositorioCuentas
    {
        Task Actualizar(CuentaCreacionViewModel cuenta);
        Task Borrar(int id);
        Task<IEnumerable<Cuenta>> Buscar(int usuarioId);
        Task Crear(Cuenta cuenta);
        Task<Cuenta> ObtenerPorID(int id, int usuarioId);
    }
    public class RepositorioCuentas : IRepositorioCuentas
    {
        private readonly string connectionString;
        public  RepositorioCuentas(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("DefaultConnection"); 
        }
        public async Task Crear(Cuenta cuenta)
        {
            using var connection = new SqlConnection(connectionString);
            var id = await connection.QuerySingleAsync<int>
                        (@"insert into Cuentas(Nombre, TipoCuentaId, Balance, Descripcion) 
                        values (@Nombre, @TipoCuentaId, @Balance, @Descripcion);
                        select SCOPE_IDENTITY()", cuenta);
            cuenta.Id = id;
        }

        public async Task<IEnumerable<Cuenta>> Buscar (int usuarioId)
        {
            using var conection = new SqlConnection(connectionString);
            return await conection.QueryAsync<Cuenta>(@"
                                select cuentas.ID, cuentas.Nombre, Balance, tc.Nombre as TipoCuenta 
                                from Cuentas
                                inner join TiposCuentas tc on tc.ID = Cuentas.TipoCuentaId
                                where tc.UsuarioID = @usuarioId
                                order by tc.Orden", new { usuarioId });
        }

        public async Task<Cuenta> ObtenerPorID(int id, int usuarioId)
        {
            using var connection = new SqlConnection (connectionString);
            return await connection.QueryFirstOrDefaultAsync<Cuenta>(
                @"select cuentas.ID, cuentas.Nombre, Balance, descripcion, tc.id as TipoCuenta 
                  from Cuentas
                     inner join TiposCuentas tc on tc.ID = Cuentas.TipoCuentaId
                  where tc.UsuarioID = @usuarioId and cuentas.id = @Id", new { id, usuarioId });
        }

        public async Task Actualizar (CuentaCreacionViewModel cuenta)
        {
            using var connection = new SqlConnection(connectionString);
            await connection.ExecuteAsync(@"Update Cuentas Set Nombre= @nombre, Balance = @Balance,
                                        Descripcion = @Descripcion, TipocuentaId = @TipoCuentaId
                                        where id = @Id", cuenta);


        }

        public async Task Borrar(int id)
        {
            using var connection = new SqlConnection(connectionString);
            await connection.ExecuteAsync(@"delete Cuentas where id = @id", new { id });

        }
    }
}
